+++
title = 'About'
date = 2024-12-05T11:10:36+08:00
draft = false
+++

European Association for Health Information and Libraries	Search for: Search

menu items: Home, About, Join, JEAHIL, Special Interest Groups, Events, Contact

The European Association for Health Information and Libraries is an active association uniting librarians and information professionals working in medical and health science libraries in Europe.

EAHIL supports professional development, improves cooperation and enables exchanges of experience amongst its members, through a yearly meeting in the form of a workshop or a conference, the journal, via the elective member discussion email lists (EAHIL-LIST and lists of SIGs) and through various accounts on social media.


A short history of EAHIL

---
>Youtube
>Linkedin
>Facebook
>Twitter
 Contact
 E-mail		eahil-secr@lists.eahil.eu

If you wish to have an image containing your likeness removed from the website, please, contact eahil-secr@lists.eahil.eu Please see our Privacy Statement.