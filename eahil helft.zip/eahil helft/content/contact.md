---
title: 'Contact'
date: 2021-12-18T11:10:36+08:00
draft: false
language: en
---

E-mail address:
eahil-secr@lists.eahil.eu
Postal address:
Lotta Haglund
Swedish School of Sport and Health Sciences (GIH)
Library
P.O. Box 5626
SE-11486 Stockholm
SWEDEN
If you wish to have an image containing your likeness removed from the website, please, contact
eahil-secr@lists.eahil.eu
Please see our
Privacy Statement
Lotta Haglund
2023-2024, 2nd term
About Lotta
Lotta attended her first EAHIL Conference in Oslo in 1994, and has given presentations at several EAHIL events...
Marion Heymans
Administrative Liaison
About Marion
Her first EAHIL meeting was in Utrecht (1998). Since then she actively attended several EAHIL meetings, with p...


---
>Youtube
>Linkedin
>Facebook
>Twitter
 Contact
 E-mail		eahil-secr@lists.eahil.eu

If you wish to have an image containing your likeness removed from the website, please, contact eahil-secr@lists.eahil.eu Please see our Privacy Statement.
