+++
title = 'Hello World'
date = 2024-12-05T11:10:36+08:00
draft = true
+++

European Association for Health Information and Libraries	Search for: Search

menu items: Home, About, Join, JEAHIL, Special Interest Groups, Events, Contact
---

Join EAHIL

Would you like to be a part of a network for European health information professionals and librarians? Join us today.
The European Association for Health Information and Libraries (EAHIL) have members from many European countries and also other countries round the globe. EAHIL members are librarians, information specialists or commercial companies with an interest in health sciences information.
EAHIL The Association is an independent European non-governmental association, without
profit motive whose purposes are:
to unite health librarians and information officers in Europe and to act as a channel of communication between them through a journal, social media, meetings, webinars, workshops and conferences,
to support the improvement of professional skills and promote quality in European health libraries.
to seek to identify and define the needs for common effort and to initiate activities
for the benefit of health information and libraries in Europe, in co-operation with
other international and national associations, organizations and institutions.

Register to join here!

Read more about EAHIL membership

Privacy statement about personal data of EAHIL members

Get involved!

---
>Youtube
>Linkedin
>Facebook
>Twitter
 Contact
 E-mail		eahil-secr@lists.eahil.eu

If you wish to have an image containing your likeness removed from the website, please, contact eahil-secr@lists.eahil.eu Please see our Privacy Statement.