+++
title = 'Hello World'
date = 2024-12-05T11:10:36+08:00
draft = true
+++

European Association for Health Information and Libraries	Search for: Search

menu items: Home, About, Join, JEAHIL, Special Interest Groups, Events, Contact
---

Special Interest Groups

EAHIL Special Interest Groups (SIG) work within EAHIL to bring together groups of members on a subject of special interest. They contribute to the strength of EAHIL by encouraging members to take an active interest in professional affairs. SIG members must be current members of EAHIL and the establishment of new SIG are encouraged and must be approved by the Board.


CURRENT SIG GROUPS
European Veterinary Libraries Group
 The aim of the EVLG is to unite all those who are interested in and/or employed in the animal health information field

Evaluation and Metrics Group
 Bring together and connect all members who are interested in on research impact and its measurement.

Evidence-Based Information Group
 Special interest group for Evidence-Based Information – EAHIL

MeSH Information Group
 Members responsible for MeSH translations are invited to join, also open to professionals using MeSH in various applications

Closure of Public Health Information Group
 PHIG is a forum for information professionals in libraries interested in public health issues in Europe

Pharmaceutical Information Group
 EAHIL-Pharma brings together information professionals from across Europe and beyond with an interest in drug information

Training, Education and Development Group
Competencies framework, post-graduate programmes, continuing professional development


---
>Youtube
>Linkedin
>Facebook
>Twitter
 Contact
 E-mail		eahil-secr@lists.eahil.eu

If you wish to have an image containing your likeness removed from the website, please, contact eahil-secr@lists.eahil.eu Please see our Privacy Statement.
